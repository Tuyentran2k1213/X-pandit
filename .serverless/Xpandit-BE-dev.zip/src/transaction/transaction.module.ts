import { Module } from '@nestjs/common';
import * as mongooseDelete from 'mongoose-delete';

import { TransactionService } from './transaction.service';
import { TransactionController } from './transaction.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Transaction, TransactionSchema } from './entities/transaction.entity';
import { User, UserSchema } from 'src/user/entities/user.entity';

@Module({
  imports: [
    MongooseModule.forFeatureAsync([
      {
        name: Transaction.name, useFactory: () => {
          const schema = TransactionSchema;
          schema.plugin(mongooseDelete, { deletedAt: true, overrideMethods: ['findOne', 'findOneAndUpdate', 'count', 'countDocuments', 'updateOne', 'update'] });
          return schema;
        }
      }
    ]), MongooseModule.forFeatureAsync([
      {
        name: User.name, useFactory: () => {
          const schema = UserSchema;
          schema.plugin(mongooseDelete, { deletedAt: true, overrideMethods: ['findOne', 'findOneAndUpdate', 'count', 'countDocuments', 'updateOne', 'update'] });
          return schema;
        }
      }
    ])],
  controllers: [TransactionController],
  providers: [TransactionService]
})
export class TransactionModule {}
