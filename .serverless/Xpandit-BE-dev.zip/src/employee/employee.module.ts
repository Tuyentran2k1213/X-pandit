import { Module } from '@nestjs/common';
import * as mongooseDelete from 'mongoose-delete';

import { EmployeeService } from './employee.service';
import { EmployeeController } from './employee.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Employee, EmployeeSchema } from './entities/employee.entity';

@Module({
  imports: [
    MongooseModule.forFeatureAsync([
      {
        name: Employee.name, useFactory: () => {
          const schema = EmployeeSchema;
          schema.plugin(mongooseDelete, { deletedAt: true, overrideMethods: ['findOne', 'findOneAndUpdate', 'count', 'countDocuments', 'updateOne', 'update'] });
          return schema;
        }
      }
    ])],
  controllers: [EmployeeController],
  providers: [EmployeeService]
})
export class EmployeeModule {}
